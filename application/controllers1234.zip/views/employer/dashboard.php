			<div class="container">
				<div class="col-md-10 col-md-offset-1">
					<div class="row tablerow">
						<div class="col-md-12">
							<div class="">
								
								<!--
								<h1>Welcome to employer</h1>
								-->
								<div id="msg_div">
									<?php echo $this->session->flashdata('message');?>
								</div>	
							</div>
						</div>
					</div>
				</div>
			</div>
			