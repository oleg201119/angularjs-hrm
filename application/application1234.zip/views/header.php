<!DOCTYPE html>
<html lang="en">
    <head>
        <title>Hr_master</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1, user-scalable=0">
        <!-- <link rel="shortcut icon" type="image/x-icon" href="<?php //base_url('webroot/css/images/favicon.ico')?>"> -->
        <link rel="stylesheet" href="<?php echo base_url()?>webroot/css/bootstrap.min.css" type="text/css" media="all">
        <link rel="stylesheet" href="<?php echo base_url()?>webroot/css/styles.css" type="text/css" media="all">
        <link rel="stylesheet" href="<?php echo base_url(); ?>webroot/css/style.css" type="text/css" media="all">
        <link rel="stylesheet" href="<?php echo base_url()?>webroot/css/style1.css" type="text/css" media="all">
        
        <link rel="stylesheet" href="<?php echo base_url()?>webroot/css/custom.css" type="text/css" media="all">
        <link rel="stylesheet" href="<?php echo base_url()?>webroot/css/flexslider.css" type="text/css" media="all">
        
    </head>
<body>