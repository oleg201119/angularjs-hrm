<br/>
<br/>
<br/>
<!-- footer-push -->
<div id="footer-push"></div>
<!-- end of footer-push -->

<!-- footer -->
<div id="footer"> <span class="shadow-bottom"></span>
    <!-- footer-cols -->
    <div class="footer-cols">
        <!-- shell -->
        <div class="shell footer-shell">
            <div class="shell">
                <nav class="footer-nav">
                    <ul>
                        <li><a href="<?php echo base_url(); ?>homepage">Home</a></li>
                        <li><a href="<?php echo base_url(); ?>contacts">Contact Us</a></li>
                        <li><a href="<?php echo base_url(); ?>privacyPolicy">Privacy Statement</a></li>
                        <li><a href="<?php echo base_url(); ?>termsOfUse">Terms of Use</a></li>
                        <li><a href="<?php echo base_url(); ?>trademarks">Trademarks</a></li>
                    </ul>
                </nav>
            </div>
            <div class="cl">&nbsp;</div>
        </div>
        <!-- end of shell -->
    </div>
    <!-- end of footer-cols -->
    <div class="footer-bottom">
        <div class="shell">
            <p class="copyl">© Copyright
                <?= date('Y');?>
                    - All Rights Reserved<span> | </span>HR Master.</p>
        </div>
    </div>
</div>
<!-- end of footer -->
</div>
<!-- end of wrapper -->

<script type="text/javascript" src="<?= base_url()?>webroot/js/jquery-2.2.4.min.js"></script>
<!--[if lt IE 9]><script src="js/modernizr.custom.js"></script><![endif]-->
<script src="<?= base_url()?>webroot/js/jquery.flexslider-min.js"></script>
<script src="<?= base_url()?>webroot/js/functions.js"></script>
</body>

</html>