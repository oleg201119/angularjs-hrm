<div id="wrapper">
  <!-- top-nav -->
  <nav class="top-nav">
    <div class="shell"> 
      <a href="#" class="nav-btn">HOMEPAGE<span></span></a> <span class="top-nav-shadow"></span>
      <ul>
        <li <?php if($this->uri->segment(1) == '' || $this->uri->segment(1) == 'homepage'){ echo ' class="active"'; }?>><span><a href="<?php echo base_url(); ?>homepage">home</a></span></li>
        <li <?php if($this->uri->segment(1) == 'aboutUs'){ echo ' class="active"'; }?>><span><a href="<?php echo base_url(); ?>aboutUs">About Us</a></span></li>
        <li <?php if($this->uri->segment(1) == 'project'){ echo ' class="active"'; }?>><span><a href="<?php echo base_url(); ?>project">projects</a></span></li>
        <li <?php if($this->uri->segment(1) == 'solution'){ echo ' class="active"'; }?>><span><a href="<?php echo base_url(); ?>solution">solutions</a></span></li>
        <li <?php if($this->uri->segment(1) == 'jobs'){ echo ' class="active"'; }?>><span><a href="<?php echo base_url(); ?>jobs">jobs</a></span></li>
        <li <?php if($this->uri->segment(1) == 'blog'){ echo ' class="active"'; }?>><span><a href="<?php echo base_url(); ?>blog">blog</a></span></li>
        <li <?php if($this->uri->segment(1) == 'contacts'){ echo ' class="active"'; }?>><span><a href="<?php echo base_url(); ?>contacts">contacts</a></span></li>
      </ul>
    </div>
  </nav>
  <!-- end of top-nav -->
  <!-- main -->
  <div class="main"> <span class="shadow-top"></span>
    <!-- shell -->
    <div class="shell">
      <div class="container">
        <h2>Contacts</h2>
        <p><strong>HRM EMAIL CONTACT DETAILS</strong></p>
      <ul>
        <li>Sales&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; |&nbsp;<a href="mailto:sales@hrmaster.com.au">sales@hrmaster.com.au</a></li>
        <li>Accounts &nbsp;|&nbsp;<a href="mailto:accounts@@hrmaster.com.au">accounts@hrmaster.com.au</a></li>
        <li>Support&nbsp;&nbsp;&nbsp; |&nbsp;<a href="mailto:support@hrmaster.com.au">support@hrmaster.com.au</a></li>
      </ul>
      <p><br />
        <br />
        <strong>HRM PO BOX DETAILS</strong></p>
      <ul>
        <li>(T) - N/A&nbsp;(outbound calls only, Please if requred please email request)</li>
        <li>(W) - <a href="http://www.hrmaster.com.au/">www.hrmaster.com.au</a></li>
        <li>(P) - PO Box 676, Engadine, NSW, 2233</li>
      </ul>
      <p><br />
        <br />
        <strong>BANKING DETAILS</strong></p>
      <ul>
        <li>Bank - Commonwealth Bank</li>
        <li>Branch - Martain Plance</li>
        <li>BSB - </li>
        <li>A/C - </li>
        <li>ABN - </li>
      </ul>
      </div>