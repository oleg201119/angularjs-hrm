<div id="wrapper">
<!-- top-nav -->
<nav class="top-nav">
  <div class="shell"> <a href="#" class="nav-btn">HOMEPAGE<span></span></a> <span class="top-nav-shadow"></span>
    <ul>
      <li <?php if($this->uri->segment(1) == '' || $this->uri->segment(1) == 'homepage'){ echo ' class="active"'; }?>><span><a href="<?php echo base_url(); ?>homepage">home</a></span></li>
      <li <?php if($this->uri->segment(1) == 'aboutUs'){ echo ' class="active"'; }?>><span><a href="<?php echo base_url(); ?>aboutUs">About Us</a></span></li>
      <li <?php if($this->uri->segment(1) == 'project'){ echo ' class="active"'; }?>><span><a href="<?php echo base_url(); ?>project">projects</a></span></li>
      <li <?php if($this->uri->segment(1) == 'solution'){ echo ' class="active"'; }?>><span><a href="<?php echo base_url(); ?>solution">solutions</a></span></li>
      <li <?php if($this->uri->segment(1) == 'jobs'){ echo ' class="active"'; }?>><span><a href="<?php echo base_url(); ?>jobs">jobs</a></span></li>
      <li <?php if($this->uri->segment(1) == 'blog'){ echo ' class="active"'; }?>><span><a href="<?php echo base_url(); ?>blog">blog</a></span></li>
      <li <?php if($this->uri->segment(1) == 'contacts'){ echo ' class="active"'; }?>><span><a href="<?php echo base_url(); ?>contacts">contacts</a></span></li>
    </ul>
  </div>
</nav>
<!-- end of top-nav --> 
<!-- main -->
<div class="main">
<span class="shadow-top"></span> 
<!-- shell -->
<div class="shell">
<div class="container">
  <h2>Privacy Policy</h2>
</div>
<p><strong>1. General</strong> </p>
<p> The business entity of HRM (ABN 16377155715) - (HRM) owns and operate the following Human Resources website 'www.hrmaster.com.au'.</p>
<p> The HRM understands that in the course of using our website products, functions and applications, you will enter personal and sensitive information in HRM website which is critical to your business operations, compliance, and  reputation.  HRM also understand that unauthorized use of this  information may result in damage and loss to your business.</p>
<p> As part of our commitment to you, the following privacy policy  outlines how we collect, store, and manage your data within HRM website and all of it's sub-directories.</p>
<p><strong>1. Application of this privacy policy</strong></p>
<p><u>1.1 General application</u> </p>
<p>The HRM privacy policy applies to any and all personal and  sensitive information collected by the HRM regardless of whether or not,  the information was asked for or volunteered. HRM is governed by the  Australian Privacy Principles  which is located within  the Privacy  Act 1988 (Act).</p>
<p> This policy applies only to HRM and not to any other  company or organizations affiliated with HRM. Third party  organizations affiliated with the HRM such as our business partners for example (our internet web hosting provider) have  their own privacy policies and are not bound by HRM's Privacy Policy. HRM do not accept any responsibility or liability for the privacy  practices of such third parties.</p>
<p> From time to time,HRM  will review this privacy policy and  were necessary, update it. If we make changes to this policy, we will take measure to advise  users that this policy has changed via an e-mail  however it is the  responsibility of the user to ensure they keep abreast of updates..<br>
  <br>
  <strong>2. Collection and use of personal information</strong></p>
<p><u>2.1 Generally</u> </p>
<p> In order to do business with you, HRM collects personal  information from you such as your name, address, telephone number, e-mail  details, and postal address. We may also  collect your payment and banking details for billing purposes.</p>
<p> In some instances, the information you enter into HRM is  classified as sensitive in nature. The Act requires this  type of information to be managed and secured at a high level and must only be  gathered for purposes which are relevant for the functions contained within HRM. Tax file numbers of your employee is an example of sensitive information.</p>
<p><u>2.2 Methods of gathering information</u></p>
<p> In order to effectively utilise HRM, HRM gathers its  personal and sensitive information from you by way of:</p>
<ul>
  <li>Your HRM application  form (i.e. the information you put on it)</li>
  <li>The data you enter into HRM and stored within the HRM  databases</li>
  <li>Cookies</li>
</ul>
<p>This data obtained is stored in our databases, and with our internet hosting providers and used for a variety of reports and  technical support. This information helps us improve our services. For example:</p>
<ul>
  <li>HRM may need to do a 'member security check' and ring a user back  on the telephone number provided (or pass on your data to our external  programmer) for technical support purposes.</li>
  <li>HRM looks at which pages are accessed frequently and which are not so  we can ensure proper resources and bandwidth are  allocated to the proper areas.</li>
</ul>
<p><u>2.3 Cookies</u></p>
<p> In addition to information you provide us during the application process, HRM also collects data using  'cookies'. 'Cookies' are small files that are stored on your internet browser.  This information is aggregate in nature and not used to identify you  personally. The type of information HRM obtain from your cookies are used  for identifying trends and technical issues such as:</p>
<ul>
  <li>the type of internet web browser you are using to access HRM</li>
  <li>the operating system you are accessing HRM from (i.e. tablet,  windows, apple, android)</li>
  <li>the times you have logged into the HRM</li>
  <li>the IP address you use when signing into HRM</li>
  <li>how long your HRM account has remained inactive for (e.g. 10  minutes or more)</li>
</ul>
<p>The use of cookies is commonly used by reputable companies on the  internet including banks, telcos, and government departments alike. It is an  industry standard throughout the world.</p>
<p> <strong>HRM does not use cookies for any marketing purposes</strong>.</p>
<p><strong>3. Disclosure of personal information</strong></p>
<p><u>3.1 Disclosure to third parties</u></p>
<p> HRM will disclose your personal information to third parties  ONLY for the following purposes:</p>
<ul>
  <li>to provide you the service you wish to use.</li>
  <li>to provide you with proper technical support (e.g. sending your account  details to HRM's external engineer or programming  consultant ants).</li>
  <li>to provide upgrades and new features on HRM (e.g. monitoring the  computer resources of our web provider to ensure there is enough CPU or RAM  resources having regard to the overall days and times users including you, are  executing your pay runs.).</li>
  <li>if permitted or required by law or,</li>
  <li>otherwise with your consent.</li>
</ul>
<p><u>3.2 Cross Border Disclosure</u></p>
<p> Some data which is entered into HRM is stored in the United States  of America. HRM has engaged in rigorous due diligence to ensure your  data is protected in a substantially similar way, as if the data was stored in  Australia.<br>
  This means, the web hosting provider the HRM use in the United  States of America (US) is also bound by strict privacy US laws and they have  similar privacy laws (albeit not the same) regarding the security of your  information.</p>
<p><strong>4. Accessing your personal information</strong></p>
<p> You have the right to e-mail support@hrmaster.com.au and:</p>
<ul>
  <li>request access to your personal information that is held by the HRM about you.</li>
  <li>request the correction of any of your personal information that the HRM holds. HRM will take reasonable steps to make the appropriate   corrections to personal information so that it is accurate, complete and  up-to-date.</li>
</ul>
<p><strong>5. Use of your personal information to contact you</strong></p>
<p> HRM will never knowingly use HRM to send you unsolicited  commercial electronic messages. More information on the Spam Act 2003 is  available from the regulators website: www.acma.gov.au/spam</p>
<p><strong>6. Security of your personal information</strong></p>
<p> HRM will take all reasonable and practicable steps to ensure  that your personal information is properly protected from misuse, interference,  and loss, and from any unauthorized access, modification or disclosure. At the same time, HRM is committed to providing you with  innovative functions and features on multiple platforms and web browsers. As  these are not operated or controlled by the HRM, our ability to protect  your personal information is limited and HRM encourage you to be vigilant  about the protection of your own personal information. HRM recommends all  users have an up to date anti-virus, malware protection agent, and firewall  security package.</p>
<p><strong>7. Privacy complaints and enquiries</strong></p>
<p> HRM welcomes feedback about privacy issues and will attend to  all questions and complaints promptly. You can contact HRM about any privacy issues by e-mailing 
  support@hrmaster.com.au. If the HRM takes more than 30 days to respond to your privacy  complaint, or if you are dissatisfied with the outcome, you can make a  complaint to the Privacy Commissioner at the Office of the Australian  Information Commissioner. The OAIC can be contacted on 1300 363 992 or at  www.oaic.gov.au</p>
</p>
</p>

