			      <!-- footer-push -->
  <div id="footer-push"></div>
  <!-- end of footer-push -->
   <!-- footer -->
    <div  id="footer"> <span class="shadow-bottom"></span>
      <!-- footer-cols -->
      <div class="footer-cols">
        <!-- shell -->
        <div class="shell footer-shell">
          <div class="shell">
            <nav class="footer-nav">
              <ul>
                <li><a href="<?php echo base_url(); ?>homepage">Home</a></li>
                <li><a href="<?php echo base_url(); ?>contacts">Contact Us</a></li>
                <li><a href="#">Privacy Statement</a></li>
                <li><a href="#">Terms of Use</a></li>
                <li><a href="#">Trademarks</a></li>
              </ul>
            </nav>
          </div>

          <div class="cl">&nbsp;</div>
        </div>
        <!-- end of shell -->
        </div>
        <!-- end of footer-cols -->
        <div class="footer-bottom">
          <div class="shell">
          <p class="copyl">© Copyright <?= date('Y');?><span>|</span>HR Master.</p>
          </div>
        </div>
      </div>
    <!-- end of footer -->
</div>
<!-- end of wrapper -->

   
		<!-- bootbox.min.js
		<script type="text/javascript" src="http://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>
		 -->	
		<script src="<?php echo base_url(); ?>webroot/js/jquery-1.8.0.min.js"></script>
		<!--[if lt IE 9]><script src="js/modernizr.custom.js"></script><![endif]-->
		<script src="<?php echo base_url(); ?>webroot/js/jquery.flexslider-min.js"></script>	
		<script src="<?php echo base_url(); ?>webroot/js/bootstrap.min.js"></script>
		<script src="<?php echo base_url();?>webroot/js/bootbox.min.js" type="text/javascript"></script>
		<script src="<?php echo base_url(); ?>webroot/js/functions.js"></script>
		<script type="text/javascript" src="http://cdn.datatables.net/1.10.2/js/jquery.dataTables.min.js"></script>		
    	<script type="text/javascript" src="<?php echo base_url(); ?>webroot/js/cal/moment.min.js"></script>
		<script type="text/javascript" src="<?php echo base_url(); ?>webroot/js/cal/bootstrap-datetimepicker.min.js"></script>
		<script>$("#msg_div").fadeOut(10000);</script>
		
	</body>
</html>